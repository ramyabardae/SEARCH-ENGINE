/**
 *
 * @author DELL
 */
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import java.util.Iterator;
import org.bson.Document;
import com.mongodb.MongoClient;
public class remove {
    public static void remove(String r) {
      //Creating a MongoDB client
      MongoClient mongo = new MongoClient( "localhost" , 27017 );
      //Connecting to the database
      MongoDatabase database = mongo.getDatabase("myDb");
      //Creating a collection
      MongoCollection<Document> collection = database.getCollection("sampleCollection");
      //Deleting a document
      collection.deleteOne(Filters.eq("subject", r));
      System.out.println("Document deleted successfully...");
      //Retrieving the documents after the delete operation
      FindIterable<Document> iterDoc = collection.find();
      int i = 1;
      System.out.println("Remaining documents:");
      Iterator it = iterDoc.iterator();
      while (it.hasNext()) {
         System.out.println(it.next());
         i++;
      }
}
}
