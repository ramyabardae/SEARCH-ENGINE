import org.bson.Document;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.IndexOptions;
/**
 *
 * @author DELL
 */
public class search {
    static String doc;
    public static String search(String f) {
        //Logger mongoLogger = Logger.getLogger("org.mongodb.driver");
        //mongoLogger.setLevel(Level.SEVERE);
 
        //System.out.println("1] query = maths , caseSensitive = false, diacriticSensitive = false");
        String val = fullTextSearch(f, false, false);
        return val; //idk how to return vlue here.
    }


    public void insert() {
        MongoClient mongoClient = new MongoClient(new MongoClientURI("mongodb://localhost:27017"));
        MongoDatabase database = mongoClient.getDatabase("myDb");
        MongoCollection <Document> collection = database.getCollection("sampleCollection");
        collection.drop();
        collection.createIndex(new Document("subject", "text"), new IndexOptions());
        try {
            collection.insertOne(new Document("_id", 1).append("subject", "maths"));
            collection.insertOne(new Document("_id", 2).append("subject", "biology"));
            collection.insertOne(new Document("_id", 3).append("subject", "chem"));
            collection.insertOne(new Document("_id", 4).append("subject", "physics"));
            collection.insertOne(new Document("_id", 5).append("subject", "english"));
            collection.insertOne(new Document("_id", 6).append("maths book", "maths ncert class 12"));
            collection.insertOne(new Document("_id", 7).append("english book", "english ncert class 12"));
 
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            mongoClient.close();
        }
    }
 
    public static String fullTextSearch(String query, boolean caseSensitive, boolean diacriticSensitive) {
 
        MongoClient mongoClient = new MongoClient(new MongoClientURI("mongodb://localhost:27017"));
        MongoDatabase database = mongoClient.getDatabase("myDb");
        MongoCollection<Document> collection = database.getCollection("sampleCollection");
        doc=" ";
        try {
            MongoCursor<Document> cursor = null;
            cursor = collection.find(new Document("$text", new Document("$search", query).append("$caseSensitive", new Boolean(caseSensitive)).append("$diacriticSensitive", new Boolean(diacriticSensitive)))).iterator();
 
            while (cursor.hasNext()) {
                Document article = cursor.next();
                System.out.println(article);
                doc = doc + article.toString();
            }
 
            cursor.close();
 
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            mongoClient.close();
        }
        return doc;
    }
}
