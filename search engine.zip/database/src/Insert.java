import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import com.mongodb.MongoClient;
/**
 *
 * @author DELL
 */
public class Insert {
    public static void insert(String f) {
      //Creating a MongoDB client
      MongoClient mongo = new MongoClient( "localhost" , 27017 );
      //Connecting to the database
      MongoDatabase database = mongo.getDatabase("myDb");
      //Creating a collection
      database.getCollection("sampleCollection");
      //Preparing a document
      Document document = new Document();
      document.append("_id", "8");
      document.append("subject", f);
      //Inserting the document into the collection
      database.getCollection("sampleCollection").insertOne(document);
      System.out.println("Document inserted successfully");
   }
}
