import java.util.ArrayList;
import org.bson.Document;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCursor;
/**
 *
 * @author DELL
 */
public class Database {

    public static String data(){
       
        // Creating a Mongo client 
        MongoClient mongo = new MongoClient( "localhost" , 27017 ); 
        MongoDatabase database = mongo.getDatabase("myDb");
        MongoCollection<Document> collection = database.getCollection("sampleCollection");
        String myarray = " ";
        int i=0;
        try (MongoCursor<Document> cur = collection.find().iterator()) {

        while (cur.hasNext()) {

            var doc = cur.next();
            var cars = new ArrayList<>(doc.values());

            //System.out.printf("%s: %s%n", cars.get(0), cars.get(1));
            myarray=myarray + " \n" + cars.get(1).toString();
            //System.out.println(myarray[i]);
            i++;
            //tree = tree + myarray[i];
            //fullName(myarray);
            }
        }
        System.out.println(myarray);
        return myarray;
    }
}
